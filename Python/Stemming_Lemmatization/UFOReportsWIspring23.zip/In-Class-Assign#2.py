#Inclass Assignment
import nltk
from nltk import word_tokenize

#Import data from the file
with open('UFOReportsWIspring23.txt', 'r', encoding= 'utf-8') as file:
    UFO = file.read()

print(UFO)

#sentence:
nltk.download('punkt')
from nltk.tokenize import sent_tokenize
sentences = sent_tokenize(UFO)
print(sentences)
for index,s in sentences:
    print(index, "  ",s)

#Words
#word_tokens = nltk.word_tokenize(sentences)






